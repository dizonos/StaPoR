import sys
import matplotlib.pyplot as plt
import openpyxl
import sqlite3
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QMainWindow, QDialog, QTableWidgetItem, QWidget
from PyQt5.QtWidgets import QLabel, QFileDialog
from PyQt5 import uic


class MainForm(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('main_window.ui', self)
        self.data = sqlite3.connect('db/основа.db')
        names = self.data.cursor().execute("SELECT title FROM pupils").fetchall()
        for i, name in enumerate(names):
            self.comboBox.addItem(name[0])
        x = self.data.cursor().execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
        x = [i[0] for i in x]
        del x[x.index('journal')]
        del x[x.index('pupils')]
        for i in x:
            self.comboBox_2.addItem(i)
        self.new_table.clicked.connect(self.create_table)
        self.show_progress.clicked.connect(self.create_progress)
        self.pushButton_7.clicked.connect(self.stat_for_work)
        self.pushButton_3.clicked.connect(self.open_table)
        self.main_table()

    def open_table(self):
        fname = QFileDialog.getOpenFileName(
            self, 'Выбрать таблицу', '',
            'Таблица (*.xlsx);')[0]
        self.form1 = AddTable(fname)
        self.form1.show()

    def main_table(self):
        header = self.data.cursor().execute("pragma table_info(journal)").fetchall()
        grade = self.data.cursor().execute("SELECT * FROM journal").fetchall()
        name = self.data.cursor().execute("SELECT title from pupils").fetchall()
        header = [i[1] for i in header[1:]]
        self.tableWidget.clear()
        self.tableWidget.setColumnCount(len(header))
        self.tableWidget.setRowCount(0)
        self.tableWidget.setHorizontalHeaderLabels(header)
        for i, row in enumerate(grade):
            self.tableWidget.setRowCount(self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                if j == 0:
                    self.tableWidget.setItem(i, j, QTableWidgetItem(str(name[i][0])))
                else:
                    self.tableWidget.setItem(i, j,  QTableWidgetItem(str(elem)))

    def stat_for_work(self):
        name = self.comboBox_2.currentText()
        nums = self.data.cursor().execute(f"SELECT {name} FROM journal").fetchall()
        x_and_y = dict()
        for i in list(set(nums)):
            if i not in x_and_y:
                x_and_y[i[0]] = 1
            else:
                x_and_y[i[0]] += 1
        x = x_and_y.keys()
        y = x_and_y.values()
        fig, ax = plt.subplots()
        ax.pie(y, labels=x)
        plt.savefig('pict/pie.jpg')
        self.form1 = ShowStat(list(x), list(y), name, 'pie.jpg')
        self.form1.show()

    def create_progress(self):
        name = self.comboBox.currentText()
        name = self.data.cursor().execute(f"SELECT id FROM pupils WHERE title = '{name}'").fetchall()
        x = self.data.cursor().execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
        x = [i[0] for i in x]
        del x[x.index('journal')]
        del x[x.index('pupils')]
        y = self.data.cursor().execute("SELECT * FROM journal WHERE ФИО = ?", (name[0][0],)).fetchall()
        y = list(y[0])[2:]
        fig, ax = plt.subplots()
        ax.plot(x, y)
        plt.savefig('pict/figure.jpg')
        self.form1 = ShowStat(x, y, name[0][0], 'figure.jpg')
        self.form1.show()

    def create_table(self):
        self.form1 = NewTable('Создание таблицы')
        self.form1.show()


class AddTable(QWidget):
    def __init__(self, name):
        super().__init__()
        self.workbook = openpyxl.open(name)
        uic.loadUi('for_table.ui', self)
        self.label_2.hide()
        self.label_3.hide()
        self.label_4.hide()
        self.lineEdit_2.hide()
        self.lineEdit_3.hide()
        self.plainTextEdit.hide()
        self.pushButton_3.hide()
        print(self.workbook.sheetnames[0])
        self.lineEdit.setText(str(self.workbook.sheetnames[0]))
        self.pushButton.clicked.connect(self.save_table)
        self.show_table()

    def show_table(self):
        worksheet = self.workbook.worksheets[0]
        self.header = [i.value for i in list(worksheet.rows)[0]]
        self.tableWidget.clear()
        self.tableWidget.setColumnCount(len(self.header))
        self.tableWidget.setRowCount(0)
        self.tableWidget.setHorizontalHeaderLabels(self.header)
        for i in range(worksheet.max_row - 1):
            self.tableWidget.setRowCount(self.tableWidget.rowCount() + 1)
            row = [i.value for i in list(worksheet.rows)[i + 1]]
            for j, elem in enumerate(row):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(elem)))

    def save_table(self):
        sqlite_connection = sqlite3.connect('db/основа.db')
        sqlite_create_table_query = f"""CREATE TABLE {self.lineEdit.text()} (
            id INT PRIMARY KEY,
            ФИО INT REFERENCES pupils (id),"""
        for i in self.header[1:-1]:
            sqlite_create_table_query += f"\n\t{i} INT,"
        sqlite_create_table_query += f'\n\t{self.header[-1]} INT'
        sqlite_create_table_query += '\n);'
        cursor = sqlite_connection.cursor()
        cursor.execute(sqlite_create_table_query)
        sqlite_connection.commit()
        for i in range(self.tableWidget.rowCount()):
            sqlite_connection.commit()
            data = [i + 1]
            for j in range(len(self.header)):
                if j == 0:
                    data.append(i + 1)
                else:
                    data.append(int(self.tableWidget.item(i, j).text()))
            stroka = "INSERT INTO "
            stroka += self.lineEdit.text() + " VALUES(?, "
            stroka += ', '.join('?' for _ in range(len(self.header)))
            stroka += ')'
            cursor.execute(stroka, data)
            sqlite_connection.commit()

        cursor.execute(f"ALTER TABLE journal ADD COLUMN {self.lineEdit.text()} INT NOT NULL DEFAULT (-1);")
        sqlite_connection.commit()
        sqlite_connection.close()
        sqlite_connection = sqlite3.connect('db/основа.db')
        cursor = sqlite_connection.cursor()
        for i in range(self.tableWidget.rowCount()):
            name = self.lineEdit.text()
            n = int(self.tableWidget.item(i, 1).text())
            cursor.execute(f"""UPDATE journal
                                        SET {name} = ?
                                        WHERE id = ?""", (n, i + 1))
            sqlite_connection.commit()
        sqlite_connection.close()


class ShowStat(QWidget):
    def __init__(self, *args):
        super().__init__()
        self.initUI(args)

    def initUI(self, args):
        works = args[0]
        num = args[1]
        pict = args[-1]
        self.setGeometry(300, 300, 700, 600)
        self.label = QLabel(self)
        self.label.resize(640, 480)
        self.label.move(30, 20)
        self.label.setPixmap(QPixmap(f'pict/{pict}'))
        if args[-1] == 'figure.jpg':
            self.setWindowTitle(f'Успеваемость: {args[2]}')
            worst = []
            ex = min(num)
            for i in sorted(num):
                if ex == i:
                    worst.append(works[num.index(i)])
                else:
                    break
            best = []
            ex = max(num)
            for i in sorted(num, reverse=True):
                if ex == i:
                    best.append(works[num.index(i)])
                else:
                    break
            self.worst = QLabel(self)
            stroka = '\n'.join(i for i in worst)
            if len(worst) > 1:
                self.worst.setText(f"Хуже всего написаны работы:\n {stroka}")
            else:
                self.worst.setText(f"Хуже всего написана работа:\n {stroka}")
            self.worst.adjustSize()
            self.worst.move(20, 510)

            stroka = '\n'.join(i for i in best)
            self.best = QLabel(self)
            if len(worst) > 1:
                self.best.setText(f"Лучше всего написаны работы: \n {stroka}")
            else:
                self.best.setText(f"Лучше всего написана работа: \n {stroka}")
            self.best.adjustSize()
            self.best.move(500, 510)
        elif args[-1] == 'pie.jpg':
            self.setWindowTitle(f'Статисктика по {args[2]}')
            sqlite_connection = sqlite3.connect('db/основа.db')
            x, y = 20, 510
            for i in range(len(works)):
                self.label1 = QLabel(self)
                self.label1.move(x, y)
                data = sqlite_connection.cursor().execute(f"SELECT title from pupils WHERE id IN "
                                                   f"(SELECT ФИО FROM journal WHERE {args[2]} = {works[i]})").fetchall()
                data = '\n'.join(i[0] for i in data)
                self.label1.setText(f"{works[i]}:\n {data}")
                self.label1.adjustSize()
                x += self.label1.width()
            sqlite_connection.close()


class NewTable(QDialog):
    def __init__(self, *args):
        super().__init__()
        uic.loadUi('for_table.ui', self)
        self.setWindowTitle(args[0])
        self.pushButton_3.clicked.connect(self.show_table)
        self.pushButton.clicked.connect(self.save_table)
        self.pushButton_2.clicked.connect(self.close)

    def close(self):
        self.hide()

    def show_table(self):  # предусмотреть ошибки в этой части в частности если существует таблица
        self.header = ['ФИО', 'Оценка']
        self.db = sqlite3.connect('db/основа.db')
        self.var = 0 if self.lineEdit_2.text() == '0' or self.lineEdit_2.text() == '1' else 1
        self.num = int(self.lineEdit_3.text())
        if self.var:
            self.header.append('Вариант')
        names = self.db.cursor().execute("SELECT title FROM pupils").fetchall()
        self.tableWidget.clear()
        self.row = 2 + self.var + self.num
        self.tableWidget.setColumnCount(self.row)
        self.tableWidget.setRowCount(0)
        if not self.plainTextEdit.toPlainText():
            for i in range(1, self.num + 1):
                self.header.append(f'Задание_{i}')
        else:
            for i in self.plainTextEdit.toPlainText().split(';'):
                self.header.append(i.strip())
        self.tableWidget.setHorizontalHeaderLabels(self.header)
        for i, row in enumerate(names):
            self.tableWidget.setRowCount(self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                if j == 0:
                    self.tableWidget.setItem(i, j, QTableWidgetItem(str(elem)))
        self.db.close()

    def save_table(self):
        sqlite_connection = sqlite3.connect('db/основа.db')
        sqlite_create_table_query = f"""CREATE TABLE {self.lineEdit.text()} (
    id INT PRIMARY KEY,
    ФИО INT REFERENCES pupils (id),"""
        for i in self.header[1:-1]:
            sqlite_create_table_query += f"\n\t{i} INT,"
        sqlite_create_table_query += f'\n\t{self.header[-1]} INT'
        sqlite_create_table_query += '\n);'
        cursor = sqlite_connection.cursor()
        cursor.execute(sqlite_create_table_query)
        sqlite_connection.commit()
        for i in range(self.tableWidget.rowCount()):
            sqlite_connection.commit()
            data = [i + 1]
            for j in range(len(self.header)):
                if j == 0:
                    data.append(i + 1)
                else:
                    data.append(int(self.tableWidget.item(i, j).text()))
            stroka = "INSERT INTO "
            stroka += self.lineEdit.text() + " VALUES(?, "
            stroka += ', '.join('?' for _ in range(len(self.header)))
            stroka += ')'
            cursor.execute(stroka, data)
            sqlite_connection.commit()

        cursor.execute(f"ALTER TABLE journal ADD COLUMN {self.lineEdit.text()} INT NOT NULL DEFAULT (-1);")
        sqlite_connection.commit()
        sqlite_connection.close()
        sqlite_connection = sqlite3.connect('db/основа.db')
        cursor = sqlite_connection.cursor()
        for i in range(self.tableWidget.rowCount()):
            name = self.lineEdit.text()
            n = int(self.tableWidget.item(i, 1).text())
            cursor.execute(f"""UPDATE journal
                                SET {name} = ?
                                WHERE id = ?""", (n, i + 1))
            sqlite_connection.commit()
        sqlite_connection.close()


def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = MainForm()
    form.show()
    sys.excepthook = except_hook
    sys.exit(app.exec())